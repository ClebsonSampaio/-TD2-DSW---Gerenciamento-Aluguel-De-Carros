export interface Person {
  id: string;
  nome: string;
  email: string;
  telefone: string;
}
