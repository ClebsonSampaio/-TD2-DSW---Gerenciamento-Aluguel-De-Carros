export interface Car {
  id: string;
  marca: string;
  modelo: string;
  ano: number;
  precoPorDia: number;
  disponivel: boolean;
  placa: string;
  kmRodado: number;
}
